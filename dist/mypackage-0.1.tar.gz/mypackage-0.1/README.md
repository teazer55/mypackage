# mypackage
This libraby was created as a an example of how to publish my own Python package

# How to install
...